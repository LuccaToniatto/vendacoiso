﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SisTDS06
{
    class Pedido
    {
        public int Id { get; set; }
        public string cpfCliente { get; set; }
        public int idProduto { get; set; }
        public int quantidade { get; set; }
        public decimal valorUnid { get; set; }
        public decimal valorTotal { get; set; }
        public string status { get; set; }

        public List<Pedido> listaPedido()
        {
            List<Pedido> li = new List<Pedido>();
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Pedido";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                Pedido p = new Pedido();
                p.Id = (int)dr["Id"];
                p.cpfCliente = dr["cpfCliente"].ToString();
                p.idProduto = (int)dr["idProduto"];
                p.quantidade = (int)dr["quantidade"];
                p.valorUnid = Convert.ToDecimal(dr["valorUnid"]);
                p.valorTotal = Convert.ToDecimal(dr["valorTotal"]);
                p.status = dr["status"].ToString();
                li.Add(p);
            }
            return li;
        }

        public void InserirVenda(string cpfCliente, int idProduto, int quantidade, decimal valorUnid, string status)
        {
            string unidValue = valorUnid.ToString();
            unidValue = unidValue.Replace(',', '.');
            var total = valorUnid * quantidade;
            string totalValue = total.ToString();
            totalValue = totalValue.Replace(',', '.');

            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "INSERT INTO Pedido(cpfCliente,idProduto,quantidade,valorUnid,valorTotal,status) VALUES ('" + cpfCliente + "','" + idProduto + "'," + quantidade + ",'" + unidValue + "','" + totalValue + "','" + status + "')";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void LocalizarVenda(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "SELECT * FROM Venda WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                cpfCliente = dr["cpfCliente"].ToString();
                idProduto = (int)dr["idProduto"];
                quantidade = (int)dr["quantidade"];
                valorUnid = Convert.ToDecimal(dr["valorUnid"]);
                valorTotal = Convert.ToDecimal(dr["valorTotal"]);
                status = dr["status"].ToString();
            }
        }

        public void AtualizarProduto(int id, string cpfCliente, int idProduto, int quantidade, decimal valorUnid)
        {
            string unidValue = valorUnid.ToString();
            unidValue = unidValue.Replace(',', '.');
            var total = valorUnid * quantidade;
            string totalValue = total.ToString();
            totalValue = totalValue.Replace(',', '.');

            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "UPDATE Venda SET cpfCliente='" + cpfCliente + "', idProduto='" + idProduto + "',quantidade=" + quantidade + ",valorUnid='" + unidValue + "',valorTotal='" + totalValue + "' WHERE Id = '" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }

        public void ExcluirVenda(int id)
        {
            SqlConnection con = ClassConecta.ObterConexao();
            SqlCommand cmd = con.CreateCommand();
            cmd.CommandText = "DELETE FROM Venda WHERE Id='" + id + "'";
            cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            ClassConecta.FecharConexao();
        }
    }
}
